module.exports = {
  name: "reactionrole",
  description: "sets up reaction role message!",
  async execute(message, args, Discord, client) {
    const channel = "912644047573766145";
    const moderatorRole = message.guild.roles.cache.find((role) => role.name === "Moderator");
    const gamerRole = message.guild.roles.cache.find((role) => role.name === "Gamer");

    const moderatorRoleEmoji = "🍋";
    const gamerRoleEmoji = "🎮";

    let embed = new Discord.MessageEmbed()
      .setColor("#e42643")
      .setTitle("Choose a role!")
      .setDescription(
        "Choosing a role will give you set permissions!\n\n" +
          `${moderatorRoleEmoji} for Moderator\n` +
          `${gamerRoleEmoji} for Gamer`
      );

    let messageEmbed = await message.channel.send(embed);
    messageEmbed.react(moderatorRoleEmoji);
    messageEmbed.react(gamerRoleEmoji);

    client.on('messageReactionAdd', async (reaction, user) => {
        if (reaction.message.partial) await reaction.message.fetch();
        if (reaction.partial) await reaction.fetch();
        if (user.bot) return;
        if (!reaction.message.guild) return;

        if (reaction.message.channel.id == channel) {
            if (reaction.emoji.name === moderatorRoleEmoji) {
                await reaction.message.guild.members.cache.get(user.id).roles.add(moderatorRole);
            }
            if (reaction.emoji.name === gamerRoleEmoji) {
                await reaction.message.guild.members.cache.get(user.id).roles.add(gamerRole);
            }
        } else {
            return;
        }

    });

    client.on('messageReactionRemove', async (reaction, user) => {

        if (reaction.message.partial) await reaction.message.fetch();
        if (reaction.partial) await reaction.fetch();
        if (user.bot) return;
        if (!reaction.message.guild) return;


        if (reaction.message.channel.id == channel) {
            if (reaction.emoji.name === moderatorRoleEmoji) {
                await reaction.message.guild.members.cache.get(user.id).roles.remove(moderatorRole);
            }
            if (reaction.emoji.name === gamerRoleEmoji) {
                await reaction.message.guild.members.cache.get(user.id).roles.remove(gamerRole);
            }
        } else {
            return;
        }
    });
}

}   